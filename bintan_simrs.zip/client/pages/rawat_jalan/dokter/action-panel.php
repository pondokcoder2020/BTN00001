<div class="row">
	<div class="col-md-12">
		<button type="button" class="btn btn-success" id="btnSelesai">
			<i class="fa fa-check-circle"></i> Selesai
		</button>
		<button type="button" class="btn btn-info" id="btnRI">
			<i class="fa fa-bed"></i> Rawat Inap
		</button>
		<button type="button" class="btn btn-warning" id="btnSelesai">
			<i class="fa fa-ambulance"></i> Rujuk
		</button>
		<a href="<?php echo __HOSTNAME__; ?>/rawat_jalan/dokter" class="btn btn-danger">
			<i class="fa fa-ban"></i> Kembali
		</a>
	</div>
</div>