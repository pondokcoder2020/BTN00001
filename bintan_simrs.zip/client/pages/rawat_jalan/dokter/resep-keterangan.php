<div class="col-md-12" style="margin-top: 20px;">
	<b>Keterangan:</b>
	<div id="txt_keterangan_resep"></div>
</div>