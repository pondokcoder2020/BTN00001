<div class="row">
	<div class="col-md-12">
		<button type="button" class="btn btn-success" id="btnSubmit">
			<i class="fa fa-check-circle"></i> Submit
		</button>
		<a href="<?php echo __HOSTNAME__; ?>/master/laboratorium" class="btn btn-danger">
			<i class="fa fa-ban"></i> Kembali
		</a>
	</div>
</div>