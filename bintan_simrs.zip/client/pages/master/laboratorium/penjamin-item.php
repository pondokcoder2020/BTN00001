<div class="row">
	<div class="col-lg">
		<div class="card">
			<div class="card-header card-header-large bg-white d-flex align-items-center">
				<h5 class="card-header__title flex m-0">Kategori Laboratorium</h5>
			</div>
			<div class="card-body">
				<table class="table table-bordered" id="penjamin-lab">
					<thead>
						<tr>
							<th class="wrap_content">No</th>
							<th>Penjamin</th>
							<th>Harga</th>
							<th>Aksi</th>
						</tr>
					</thead>
					<tbody></tbody>
				</table>
			</div>
		</div>
	</div>
</div>