<div class="card-group">
	<div class="card card-body">
		<div class="d-flex flex-row">
			<div class="col-md-12">
				<b class="label_kode">[KODE BARANG]</b>
				<br />
				<span class="label_nama">[NAMA BARANG]</span>
				<br />
				<span class="label_manufacture">[MANUFACTURE]</span>
				<br />
				<span class="label_kategori">[KATEGORI]</span>
			</div>
		</div>
	</div>
	<div class="card card-body">
		<div class="d-flex flex-row">
			<div class="col-md-12 load-kategori-obat-badge">
			</div>
		</div>
	</div>
</div>