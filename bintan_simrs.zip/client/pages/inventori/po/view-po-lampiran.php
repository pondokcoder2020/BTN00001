<div class="row">
	<div class="col-lg-12">
		<table class="table table-bordered largeDataType" id="po_document_table">
			<thead class="thead-dark">
				<tr>
					<th style="width: 20px;">No</th>
					<th>Dokumen</th>
					<th class="wrap_content">Aksi</th>
				</tr>
			</thead>
			<tbody></tbody>
		</table>
	</div>
</div>