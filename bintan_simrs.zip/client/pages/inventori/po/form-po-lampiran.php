<div class="row">
	<div class="col-lg-12">
		<h5 class="text-center">
			<div class="custom-upload btn btn-success">
				<input type="file" id="add_file" /><i class="fa fa-upload"></i> Upload
			</div>

		</h5>
		<table class="table table-bordered largeDataType" id="po_document_table">
			<thead>
				<tr>
					<th style="width: 20px;">No</th>
					<th>Dokumen</th>
					<th class="wrap_content">Aksi</th>
				</tr>
			</thead>
			<tbody></tbody>
		</table>
	</div>
</div>