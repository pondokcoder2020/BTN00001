<?php
	session_destroy();
?>