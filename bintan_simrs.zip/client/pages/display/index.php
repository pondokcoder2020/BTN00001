<div class="anjungan-container" style="overflow: hidden;">
	<div class="container-fluid" style="padding: 0 !important; overflow: hidden;">
		<div class="row">
			<div class="col-md-12">
				<div class="card" style="background: transparent;">
					<div class="card-body" style="background: rgba(0, 0, 0, .7);">
						<table>
							<tr>
								<td>
									<img width="120" height="100" src="<?php echo __HOSTNAME__; ?>/template/assets/images/logo.png" />			
								</td>
								<td>
									<h3 style="color: #fff">RUMAH SAKIT UMUM DAERAH BINTAN</h3>
									<i class="fa fa-map-marker" style="color: red;"></i> <span style="color: #fff">Jalan Dr. Soetomo No. 65, Sekip, LimaPuluh, Kota Pekanbaru, Riau 28155. Telp. (0761)23024</span>
								</td>
							</tr>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="container-fluid" style="overflow: hidden;">
		<div class="row">
			<div class="col-md-4">
				<center>
					<h1 style="padding: 10px !important; color: yellow; font-weight: bold;">ANTRIAN</h1>

					<div style="background: #000; border-radius: 10px;">
						<h1 class="blink_me" id="current_antrian" style="font-size: 80pt; color: #fff">0</h1>
					</div>
				</center>
				<div class="row" id="loket-loader">
					
				</div>
			</div>
			<div class="col-md-8">
				<div class="row">
					<div class="col-md-12">
						<div id="carousel-slider" class="carousel slide" data-ride="carousel">
							<div class="carousel-inner">
							</div>
						</div>
					</div>
					<div class="col-md-12">
						<div id="info-kamar" class="carousel slide" data-ride="carousel">
							<div class="carousel-inner">
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>